import csv, math, statistics as st

rows = []
with open('prices.csv') as f:
    for r in csv.DictReader(f):
        rows.append((r['date'], float(r['open']), float(r['high']), float(r['low']), float(r['close']), float(r['volume'])))
rows.sort()
dates = [r[0] for r in rows]
closes = [r[4] for r in rows]
n = len(rows)
rets = [closes[i]/closes[i-1]-1 for i in range(1, n)]
gap = [rows[i][1]/rows[i-1][4]-1 for i in range(1, n)]  # open vs prev close

def stats(xs):
    if len(xs) < 2: return None
    m = st.mean(xs); s = st.stdev(xs)
    pup = sum(1 for x in xs if x > 0)/len(xs)
    return dict(n=len(xs), mean=100*m, sd=100*s, med=100*st.median(xs), p_up=pup,
                min=100*min(xs), max=100*max(xs),
                p_gt2=sum(1 for x in xs if x>0.02)/len(xs), p_lt_2=sum(1 for x in xs if x<-0.02)/len(xs))

# 5-day forward returns
fwd5 = [closes[i+5]/closes[i]-1 for i in range(n-5)]
print("ALL 5d fwd (all history):", {k: round(v,3) for k,v in stats(fwd5).items()})

# recent 1yr and 2yr windows
for label, k in [("1yr",252), ("2yr",486), ("3yr", n-1)]:
    w = fwd5[-k:]
    print(f"5d fwd last {label}:", {kk: round(v,3) for kk,v in stats(w).items()})

# daily ret stats recent
for label, k in [("10d",10),("20d",20),("60d",60),("252d",252)]:
    w = rets[-k:]
    print(f"daily ret last {label}: mean={100*st.mean(w):.3f}% sd={100*st.stdev(w):.3f}%  5d_sd~{100*st.stdev(w)*math.sqrt(5):.2f}%")

# after big up days (same-day ret >= 8%)
idx_big = [i for i in range(1, n-5) if rets[i-1] >= 0.08]
fwd5_big = [closes[i+5]/closes[i]-1 for i in idx_big]
print("\nBig up day (>=+8%) history:", [ (dates[i], f"{100*rets[i-1]:.1f}%") for i in idx_big])
print("5d fwd after big up day:", {k: round(v,3) for k,v in stats(fwd5_big).items()})

# after gap up >= 4%
idx_gap = [i for i in range(1, n-5) if gap[i] >= 0.04]
fwd5_gap = [closes[i+5]/closes[i]-1 for i in idx_gap]
print("\nGap up (>=+4%) days:", [(dates[i], f"{100*gap[i]:.1f}%") for i in idx_gap])
print("5d fwd after gap up:", {k: round(v,3) for k,v in stats(fwd5_gap).items()})

# after any up day >=5%
idx_up5 = [i for i in range(1, n-5) if rets[i-1] >= 0.05]
fwd5_up5 = [closes[i+5]/closes[i]-1 for i in idx_up5]
print("\nUp day >=+5%:", [(dates[i], f"{100*rets[i-1]:.1f}%") for i in idx_up5])
print("5d fwd after up>=5%:", {k: round(v,3) for k,v in stats(fwd5_up5).items()})

# next-day after big up
nd_big = [closes[i+1]/closes[i]-1 for i in idx_big]
nd_gap = [closes[i+1]/closes[i]-1 for i in idx_gap]
print("\nNext-day after big up:", {k: round(v,3) for k,v in stats(nd_big).items()})
print("Next-day after gap up:", {k: round(v,3) for k,v in stats(nd_gap).items()})

# 2d fwd after big up
fwd2_big = [closes[i+2]/closes[i]-1 for i in idx_big]
print("2d fwd after big up:", {k: round(v,3) for k,v in stats(fwd2_big).items()})

# last 10 closes & recent move
print("\nlast 12 closes:", [round(c,2) for c in closes[-12:]])
print("today ret: %.2f%%  gap: %.2f%%" % (100*rets[-1], 100*gap[-1]))
print("vol today vs 20d avg vol: %.1fx" % (rows[-1][5]/st.mean(r[5] for r in rows[-21:-1])))
