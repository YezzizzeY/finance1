import pandas as pd, numpy as np
df=pd.read_csv('prices.csv',parse_dates=['date']).sort_values('date').reset_index(drop=True)
df['ret']=df.close.pct_change(); df['fwd5']=df.close.shift(-5)/df.close-1
df['gap']=df.open/df.close.shift(1)-1
df['ema21']=df.close.ewm(span=21).mean(); df['ema55']=df.close.ewm(span=55).mean()
df['pos_in_range']=(df.close-df.low)/(df.high-df.low)
df['v20']=df.ret.rolling(20).std()
def show(name,m):
    s=df.loc[m,'fwd5'].dropna()
    if len(s): print(f"{name}: n={len(s)} mean={s.mean()*100:+.2f}% med={s.median()*100:+.2f}% sd={s.std()*100:.2f}% p_up={(s>0).mean():.2f}")
show("gap>5%", df.gap>0.05)
show("gap>5% & close strong(>0.8)", (df.gap>0.05)&(df.pos_in_range>0.8))
show("gap>5% & above ema21", (df.gap>0.05)&(df.close>df.ema21))
show("gap>5% & below 52w-high by>15%", (df.gap>0.05)&(df.close<df.close.rolling(250).max()*0.85))
show("cross above ema55 from below", (df.close>df.ema55)&(df.close.shift(1)<=df.ema55.shift(1)))
show("ret>5% & close>ema55", (df.ret>0.05)&(df.close>df.ema55))
show("v20>4% & ret>5%", (df.v20>0.04)&(df.ret>0.05))
# 5d fwd distribution in high vol regime
m=df.v20.shift(1)>0.04
show("high 20d vol regime", m)
s=df.loc[m,'fwd5'].dropna(); print("  -> that sd",s.std()*100)
print("\nRecent 20d ret:", df.close.pct_change(20).iloc[-1]*100)
print("52w high:", df.close.tail(250).max(), "ratio", df.close.iloc[-1]/df.close.tail(250).max())
print("close vs ema55 %.2f, ema21 %.2f"%(df.ema55.iloc[-1], df.ema21.iloc[-1]))
# vol estimate blend
daily=[df.ret.tail(n).std() for n in (10,20,60)]
print("daily vol 10/20/60:", [f"{d*100:.2f}" for d in daily])
print("5d vol from 20d:", daily[1]*np.sqrt(5)*100, "from 10d:", daily[0]*np.sqrt(5)*100)
