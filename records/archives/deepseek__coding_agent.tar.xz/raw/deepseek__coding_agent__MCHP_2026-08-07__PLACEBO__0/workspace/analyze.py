import pandas as pd, numpy as np
df=pd.read_csv('prices.csv',parse_dates=['date']).sort_values('date').reset_index(drop=True)
df['ret']=df.close.pct_change()
print(len(df), df.date.min(), df.date.max())
print(df.tail(3))
# distribution of 5-day forward returns
df['fwd5']=df.close.shift(-5)/df.close-1
print("\nbase 5d fwd: mean %.2f%% sd %.2f%%"%(df.fwd5.mean()*100, df.fwd5.std()*100))
print("base p_up %.2f"%((df.fwd5>0).mean()))
# conditional on big up days
for thr in [0.06,0.08,0.10,0.12]:
    m=df.ret>thr
    s=df.loc[m,'fwd5'].dropna()
    print(f"\nret>{thr*100:.0f}%: n={len(s)} mean={s.mean()*100:.2f}% med={s.median()*100:.2f}% sd={s.std()*100:.2f}% p_up={(s>0).mean():.2f}")
    print(df.loc[m,['date','ret']].assign(fwd5=df.loc[m,'fwd5']*100).tail(10).to_string())
# conditional on big up day after a drawdown: close > 5d ago by >8%, and 20d ret negative?
df['ret5']=df.close.pct_change(5); df['ret20']=df.close.pct_change(20)
m=(df.ret5>0.08)
s=df.loc[m,'fwd5'].dropna()
print(f"\n5d ret>8%: n={len(s)} mean={s.mean()*100:.2f}% sd={s.std()*100:.2f}% p_up={(s>0).mean():.2f}")
# next-day return after big up days
df['n1']=df.close.shift(-1)/df.close-1
s=df.loc[df.ret>0.10,'n1'].dropna(); print("next day after +10%%: mean %.2f%% sd %.2f%% n=%d"%(s.mean()*100,s.std()*100,len(s)))
# realized daily vol last 10/20/60
for n in [10,20,60,120]:
    print(f"realized daily vol {n}d: {df.ret.tail(n).std()*100:.2f}%  ann {df.ret.tail(n).std()*np.sqrt(252)*100:.1f}%")
# 5-day rolling vol in high-vol regimes
print("\nEmpirical 5d return sd overall: %.2f%%"%(df.fwd5.std()*100))
# conditional after high-vol days
df['v10']=df.ret.rolling(10).std()
m=(df.v10>0.04)&(df.ret>0.08)
s=df.loc[m,'fwd5'].dropna(); print(f"after high vol & big up: n={len(s)} mean={s.mean()*100:.2f}% sd={s.std()*100:.2f}%")
# gap open analysis: open vs prev close
df['gap']=df.open/df.close.shift(1)-1
print(df.tail(5)[['date','open','close','ret','gap']])
