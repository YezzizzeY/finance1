import pandas as pd
import numpy as np
from datetime import datetime, timedelta
import json

# Load price data
df = pd.read_csv('prices.csv', parse_dates=['date'])
df = df.sort_values('date')

# Get today's data (latest bar)
today = df['date'].max()
close_price = df.loc[df['date'] == today, 'close'].values[0]

print(f"Today's date: {today}")
print(f"Today's close: {close_price:.2f}")

# Calculate technical indicators
# Get prices for RSI
returns = df['close'].pct_change().dropna()

# RSI (14)
def rsi(prices, period=14):
    delta = prices.diff()
    gain = (delta.where(delta > 0, 0)).rolling(window=period).mean()
    loss = (-delta.where(delta < 0, 0)).rolling(window=period).mean()
    rs = gain / loss
    return 100 - (100 / (1 + rs))

rsi_vals = rsi(df['close'])
print(f"RSI: {rsi_vals.iloc[-1]:.2f}")

# EMA crossovers
def ema(df, period):
    return df['close'].ewm(span=period, adjust=False).mean()

ema5 = df['close'].ewm(span=5, adjust=False).mean()
ema21 = df['close'].ewm(span=21, adjust=False).mean()
ema8 = df['close'].ewm(span=8, adjust=False).mean()
ema55 = df['close'].ewm(span=55, adjust=False).mean()

print(f"EMA5: {ema5.iloc[-1]:.2f}")
print(f"EMA8: {ema8.iloc[-1]:.2f}")
print(f"EMA21: {ema21.iloc[-1]:.2f}")
print(f"EMA55: {ema55.iloc[-1]:.2f}")

# Bollinger Bands
sma20 = df['close'].rolling(window=20).mean()
std20 = df['close'].rolling(window=20).std()
upper = sma20 + 2 * std20
lower = sma20 - 2 * std20
print(f"Bollinger Upper: {upper.iloc[-1]:.2f}")
print(f"Bollinger Lower: {lower.iloc[-1]:.2f}")
print(f"Close position in BB: {(close_price - lower.iloc[-1]) / (upper.iloc[-1] - lower.iloc[-1]):.2%}")

# MACD
exp12 = df['close'].ewm(span=12, adjust=False).mean()
exp26 = df['close'].ewm(span=26, adjust=False).mean()
macd = exp12 - exp26
signal_line = macd.ewm(span=9, adjust=False).mean()
macd_hist = macd - signal_line
print(f"MACD: {macd.iloc[-1]:.2f}")
print(f"MACD Signal: {signal_line.iloc[-1]:.2f}")
print(f"MACD Histogram: {macd_hist.iloc[-1]:.2f}")

# Volatility
ann_vol_20 = np.std(df['close'].pct_change()[7:] * 252 * 100)  # Annualized
atr_14 = df['close'].ewm(com=13, adjust=False).mean()  # Approximate ATR
price_std = df['close'].pct_change().dropna().std()
print(f"20d Annualized Vol: {ann_vol_20:.2f}%")
print(f"Price Std (daily): {price_std:.4f}")

# Recent price action (last 10 days)
recent = df.tail(10)
price_changes = recent['close'].pct_change().dropna()
print(f"\nLast 10 days returns: {price_changes.tolist()}")
print(f"Recent 5-day return: {returns.tail(5).sum():.2%}")
print(f"Recent 5-day std: {returns.tail(5).std():.4f}")

# Support/Resistance
print(f"\nResistance above: 113.8, 116.19, 117.28")
print(f"Support below: 107.13")

# Position analysis based on technical signals
print("\n" + "="*50)
print("SIGNAL ANALYSIS")
print("="*50)

# Count bullish/bearish factors
bullish_factors = 0
bearish_factors = 0
factors = []

# EMA signal: close < EMA21 and EMA8 < EMA21 -> bearish
if close_price < ema21.iloc[-1]:
    factors.append(f"EMA 21 ({ema21.iloc[-1]:.2f}) above close ({close_price:.2f})")
    bearish_factors += 1
if ema8.iloc[-1] < ema21.iloc[-1]:
    factors.append(f"EMA 8 ({ema8.iloc[-1]:.2f}) below EMA 21 ({ema21.iloc[-1]:.2f})")
    bearish_factors += 1

# RSI < 30 -> oversold (buy signal)
if rsi_vals.iloc[-1] < 30:
    factors.append(f"RSI ({rsi_vals.iloc[-1]:.2f}) oversold")
    bullish_factors += 1
elif rsi_vals.iloc[-1] < 40:
    factors.append(f"RSI ({rsi_vals.iloc[-1]:.2f}) approaching oversold")

# MACD bullish cross
if macd_hist.iloc[-1] > 0:
    factors.append(f"MACD histogram positive ({macd_hist.iloc[-1]:.2f})")
    bullish_factors += 1

# Bollinger range (mean reversion potential)
bb_position = (close_price - lower.iloc[-1]) / (upper.iloc[-1] - lower.iloc[-1])
if bb_position < 0.4:
    factors.append(f"Close below mid BB, potential mean reversion")
    bullish_factors += 1
elif bb_position > 0.6:
    factors.append(f"Close above mid BB, potential pullback")
    bearish_factors += 1

# Recent trend
recent_ret = price_changes.tail(5).sum()
if recent_ret < 0:
    factors.append(f"Recent 5-day trend: {recent_ret:.2%} (down)")
    bearish_factors += 1
else:
    factors.append(f"Recent 5-day trend: {recent_ret:.2%} (up)")
    bullish_factors += 1

print(f"Bullish factors: {bullish_factors}")
print(f"Bearish factors: {bearish_factors}")

for f in factors:
    print(f"  - {f}")

# Calculate forecast parameters
# Use historical returns for estimation (last 60 days)
recent_60 = df.tail(60)
recent_60_ret = recent_60['close'].pct_change().dropna()
mean_5d_ret = recent_60_ret.rolling(window=5).apply(lambda x: x.sum(), raw=False).dropna()
if not mean_5d_ret.empty:
    mean_5d = mean_5d_ret.mean()
    std_5d = mean_5d_ret.std()
else:
    mean_5d = 0.02  # Assume 2% 5-day return average
    std_5d = 0.10   # Assume 10% 5-day std

# Adjust for current technical conditions
volatility_regime = "normal"  # Based on vol stats
vol_adjustment = 1.0
if ann_vol_20 > 25:  # High volatility
    vol_adjustment = 1.1

# p_up: probability based on mean return and volatility
p_up = 0.5 + mean_5d / (2 * std_5d)
p_up = max(0.3, min(0.7, p_up))

# expected return (5-day)
expected_return_5d = mean_5d * vol_adjustment

# expected vol (5-day one-sd)
expected_vol_5d = std_5d * vol_adjustment * 100  # Convert to percent

print(f"\nForecast Estimate:")
print(f"  p_up: {p_up:.2f}")
print(f"  expected_return_pct: {expected_return_5d:.2f}")
print(f"  expected_vol_pct: {expected_vol_5d:.2f}")

# Decision logic
decision = {
    "action": "Hold",
    "shares": 0,
    "target_exposure_pct": 5.0,
    "p_up": round(p_up, 2),
    "expected_return_pct": round(expected_return_5d, 2),
    "expected_vol_pct": round(expected_vol_5d, 2),
    "confidence": round(max(0.3, min(0.8, (bullish_factors + bearish_factors) / 7)), 2),
    "reasoning": f"Technical signals mixed: bearish trend ({bearish_factors} factors) vs oversold conditions ({bullish_factors} factors). Price below EMA21 but MACD shows bullish cross. Holding current position."
}

# If bullish factors outweigh bearish, consider small buy
if bullish_factors >= bearish_factors + 2:
    decision["action"] = "Buy"
    decision["shares"] = 9  # 1% exposure point
    decision["target_exposure_pct"] = 6.0
    decision["reasoning"] = f"Bullish reversal potential: {factors}"

# If significantly bearish, consider reduce
if bearish_factors >= bullish_factors + 2:
    decision["action"] = "Sell"
    decision["shares"] = 9  # 1% exposure point
    decision["target_exposure_pct"] = 4.0
    decision["reasoning"] = f"Bearish trend confirmed: {factors}"

print(f"\n" + "="*50)
print(f"DECISION: {decision['action']} {decision['shares']} shares")
print(f"Target exposure: {decision['target_exposure_pct']}%")
print("="*50)

# Save decision
with open('decision.json', 'w') as f:
    json.dump(decision, f, indent=2)

print("\ndecision.json saved!")
print(json.dumps(decision, indent=2))
