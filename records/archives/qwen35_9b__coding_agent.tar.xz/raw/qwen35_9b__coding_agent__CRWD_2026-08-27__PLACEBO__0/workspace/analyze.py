import csv
import pandas as pd
import numpy as np
from datetime import datetime

# Load prices
prices = pd.read_csv('prices.csv', parse_dates=['date'])
print(f"Price data: {len(prices)} rows")
print(f"Date range: {prices['date'].min()} to {prices['date'].max()}")

# Look around today (2026-08-27)
today = '2026-08-27'
nearby = prices[prices['date'] > '2026-08-26']
print(f"\nLast 15 closes near today:")
print(nearby[['date', 'open', 'high', 'low', 'close']].tail(15))

# Calculate daily returns
prices['ret'] = prices['close'].pct_change()
print(f"\nDaily returns around today:")
print(prices[['date', 'ret']].tail(15))

# Historical 5-day returns
returns_5d = prices.groupby(prices['date'].dt.to_period('D')).apply(
    lambda x: x.last_valid_index().to_pydatetime() if len(x) > 4 else None
)

# Rolling statistics
rolling_mean = prices['ret'].rolling(window=60, min_periods=5).mean()
rolling_std = prices['ret'].rolling(window=60, min_periods=5).std()
print(f"\nRolling stats (60-day):")
print(f"Mean: {rolling_mean.tail(1).values[0]:.4f}")
print(f"Std: {rolling_std.tail(1).values[0]:.4f}")

# Check recent volatility
recent_returns = prices['ret'].tail(20)
print(f"\nLast 20 daily returns:")
print(recent_returns)
print(f"Mean 20d: {recent_returns.mean():.4f}")
print(f"Std 20d: {recent_returns.std():.4f}")

today_close = 227.9600067138672
print(f"\nToday's close: {today_close}")
print(f"52-week high: {prices['high'].max()}")
print(f"Pct from 52w high: {(today_close - prices['high'].max()) / prices['high'].max() * 100:.2f}%")

# Expected 5-day return based on historical
print(f"\n=== Forecast estimates ===")
print(f"Mean 1-day return (historical): {prices['ret'].dropna().mean():.4f}")
print(f"Std 1-day return (historical): {prices['ret'].dropna().std():.4f}")

# Momentum adjustment: look at 5 previous day returns
avg_5d_before = prices['ret'].iloc[-25:-20].mean()
print(f"Average 5-day return (20d ago): {avg_5d_before:.4f}")
