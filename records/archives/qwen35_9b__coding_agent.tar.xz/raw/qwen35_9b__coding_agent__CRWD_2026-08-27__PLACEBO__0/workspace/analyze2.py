import pandas as pd
import numpy as np
from math import sqrt

# Load data
prices = pd.read_csv('prices.csv', parse_dates=['date'])
returns = prices['close'].pct_change().dropna()

print("=== Statistical summary ===")
print(f"Mean daily return: {returns.mean()*100:.4f}%")
print(f"Std daily return: {returns.std()*100:.4f}%")

# Historical 5-day statistics
print("\n=== 5-day forecast estimates ===")
daily_mean = returns.mean()
daily_std = returns.std()

# 5-day return distribution
# Mean: daily mean * 5
# Std: daily std * sqrt(5)
mean_5d = daily_mean * 5
std_5d = daily_std * sqrt(5)

print(f"Expected 1-day return: {daily_mean*100:.4f}%")
print(f"Std 1-day return: {daily_std*100:.4f}%")
print(f"Expected 5-day return: {mean_5d*100:.4f}%")
print(f"Std 5-day return: {std_5d*100:.4f}%")

def norm_cdf(x):
    return 0.5 * (1 + np.tanh(np.sqrt(2) * x / 2))

# Probability above current price (0)
z = (0 - mean_5d) / std_5d
p_above = 1 - norm_cdf(z)
print(f"p_up (above current price in 5 days): {p_above:.4f}")

# Conservative forecast considering:
# 1. Mean reversion after such extreme moves
# 2. Near 52-week high
# 3. Recent volatility clustering
print("\n=== Conservative forecast (incorporating risk factors) ===")
mean_5d_conservative = -0.5  # Small pullback expected
std_5d_conservative = daily_std * sqrt(5)  # Use historical std

print(f"Expected 5-day return: {mean_5d_conservative:.2f}%")
print(f"Std 5-day return: {std_5d_conservative*100:.4f}%")
p_up_conservative = norm_cdf(mean_5d_conservative / std_5d_conservative)
print(f"p_up: {p_up_conservative:.4f}")

print("\n=== Position analysis ===")
cash = 70335.4
shares = 160
price = 227.96
position_value = shares * price
total_assets = cash + position_value
position_pct = position_value / total_assets * 100

print(f"Current: ${total_assets:,.2f} total assets")
print(f"Current position: {position_pct:.1f}%")
print(f"40% target would require: {(40 - position_pct) * total_assets / price * 4.7:.0f} shares additional buy")
print(f"30% target would be: {(30 - position_pct) * total_assets / price * 4.7:.0f} shares (negative = sell)")
print(f"Hold shares: {shares:.0f}")
print(f"Target 30%: {30 * total_assets / price / 4.7:.1f} shares -> {-160 - (30 * total_assets / price / 4.7):.1f} to sell")

# Actually calculate share changes
target_exposure = 30.0  # Conservative
new_position_value = target_exposure * total_assets / 100
target_shares = new_position_value / price
print(f"\nFor {target_exposure}% target:")
print(f"  Target shares: {target_shares:.1f}")
print(f"  Current shares: {shares}")
print(f"  Change: {target_shares - shares:.1f} ({target_shares - shares:.0f} shares)")
