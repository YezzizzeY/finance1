import pandas as pd
import numpy as np
import json

# Load data - filter to 2026 data only
prices = pd.read_csv('prices.csv', parse_dates=['date'])
prices = prices[prices['date'] >= '2026-07-27']
prices = prices.sort_values('date').reset_index(drop=True)

news = pd.read_csv('news.csv', parse_dates=['time'])

account = {
    'cash': 94798.36,
    'shares': 67,
    'total_assets': 100472.59,
    'close': 84.69,
    'shares_per_exposure_point': 11.9
}

print("="*70)
print("ANALYSIS: MCHP - 2026-08-07")
print("="*70)

close = prices['close']
yesterday = prices.iloc[-2]
today = prices.iloc[-1]

print(f"\n--- TODAY's DATA ---")
print(f"Close: ${today['close']:.2f}")
print(f"Daily Move: {((today['close'] - yesterday['close']) / yesterday['close']) * 100:+.2f}%")
print(f"Volume: {today['volume']:,}")

print(f"\n--- TECHNICAL INDICATORS ---")

# EMA
ema8 = close.ewm(span=8).mean()
ema21 = close.ewm(span=21).mean()
ema55 = close.ewm(span=55).mean()

ema8_val = ema8.iloc[-1]
ema21_val = ema21.iloc[-1]  
ema55_val = ema55.iloc[-1]

print(f"EMA(8): ${ema8_val:.2f}")
print(f"EMA(21): ${ema21_val:.2f}")
print(f"EMA(55): ${ema55_val:.2f}")

ema_spread = ((ema8_val - ema55_val) / ema55_val) * 100
print(f"EMA(8/55) spread: {ema_spread:.2f}%")

# RSI
high_14 = close.rolling(14).max()
low_14 = close.rolling(14).min()
delta = diff(close)
gain = delta.where(delta > 0, 0).rolling(14).mean()
loss = delta.where(delta < 0, 0).neg().rolling(14).mean().abs()
rs = gain / loss
rsi = 100 - (100 / (1 + rs))
rsi_val = rsi.iloc[-1]
print(f"RSI(14): {rsi_val:.1f}")

# Bollinger Bands
sma_20 = close.rolling(20).mean()
std_20 = close.rolling(20).std()
bb_upper = sma_20 + 2 * std_20
bb_lower = sma_20 - 2 * std_20

bb_upper_val = bb_upper.iloc[-1]
bb_lower_val = bb_lower.iloc[-1]
bb_median_val = (bb_upper_val + bb_lower_val) / 2
bb_position = (today['close'] - bb_lower_val) / (bb_upper_val - bb_lower_val)

print(f"SMA(20): ${sma_20.iloc[-1]:.2f}")
print(f"Bollinger Upper: ${bb_upper_val:.2f}")
print(f"Bollinger Lower: ${bb_lower_val:.2f}")

# Z-score
z_score = (today['close'] - bb_median_val) / ((bb_upper_val - bb_lower_val) / 2)
print(f"Z-Score (20d): {z_score:+.2f}")

# MACD
exp1 = close.ewm(span=12).mean()
exp2 = close.ewm(span=26).mean()
macd_val = exp1 - exp2
macd_signal_val = macd_val.ewm(span=9).mean()
macd_hist_val = macd_val - macd_signal_val

print(f"\nMACD: {macd_val.iloc[-1]:.2f}")
print(f"MACD Signal: {macd_signal_val.iloc[-1]:.2f}")
print(f"MACD Histogram: {macd_hist_val.iloc[-1]:+.2f}")

# Volatility / ATR
range_14d = (prices['high'] - prices['low']).rolling(14).mean()
atr_14 = range_14d.iloc[-1]
print(f"\nATR(14): ${atr_14:.2f} ({(atr_14/today['close'])*100:.1f}%)")

# Support/Resistance
resistance = [92.02, 90.85, 85.66]
support = [72.58, 78.0, 81.6]
nearest_res = min(resistance, key=lambda x: abs(x - today['close']))
nearest_sup = max(support, key=lambda x: abs(x - today['close']))

print(f"\nNearest Resistance: ${nearest_res} (above by {nearest_res - today['close']:.2f})")
print(f"Nearest Support: ${nearest_sup} (below by {today['close'] - nearest_sup:.2f})")

# Recent returns
returns_5d = []
for i in range(20, len(prices)):
    r5 = (close.iloc[i] / close.iloc[i-5]) - 1
    returns_5d.append(r5)
returns_5d = np.array(returns_5d)

print(f"\n5-day rolling returns (last 20): min={returns_5d.min():.2f}%, max={returns_5d.max():.2f}%, mean={returns_5d.mean():.2f}%, std={returns_5d.std():.2f}%")

# News sentiment
news_recent = news.tail(10)
print(f"\n--- RECENT NEWS ---")
for _, row in news_recent.iterrows():
    text = (row['headline'] + ' ' + row['summary']).lower()
    [# Send complete analysis message
    pos_words = ['beat', 'grow', 'guidance', 'up', 'buys', 'strong']
    neg_words = ['lower', 'cut', 'bear', 'weak', 'cuts']
    has_pos = any(w in text for w in pos_words)
    has_neg = any(w in text for w in neg_words)
    if has_pos and not has_neg:
        m = " [+]"
    elif has_neg and not has_pos:
        m = " [-]"
    else:
        m = " [~]"
    print(f"{m} {row['headline'][:65]}")

# Decision
current_exposure = (account['shares'] * today['close']) / account['total_assets'] * 100
print(f"\n--- ACCOUNT ---")
print(f"Shares: {account['shares']}, Value: ${account['shares']*today['close']:.2f}")
print(f"Exposure: {current_exposure:.1f}%")

print(f"\n--- DECISION ---")
print("="*70)

# Key factors:
# 1. 13.9% single-day move - historically rare, suggests volatility cluster
# 2. Volatility regime HIGH (89.6% vs normal ~64.8%)
# 3. Z-score +1.68 suggests elevated position vs mean
# 4. Earnings beat clear, but analyst PTs lowered
# 5. Current exposure 5.6% - not too aggressive, reasonable for current state

action = "Hold"
shares = 67
target_exposure = current_exposure

print(f"\nAction: {action}")
print(f"Shares: {shares}")
print(f"Target Exposure: {target_exposure:.1f}%")

# Forecast estimates
# - Earnings momentum slightly favors upside
# - But high vol regime and z-score suggest wait
# - Conservative/neutral estimate

p_up = 0.53
expected_return = 0.5
expected_vol = 4.5
confidence = 0.55

reasoning = "Holding after 13.9% single-day move in high volatility regime (89.6% ann); fundamental strength from earnings beat balanced by technical exhaustion signals (z-score +1.68, analyst PT cuts); awaiting volatility normalization before sizing"

decision = {
    "action": action,
    "shares": shares,
    "target_exposure_pct": round(target_exposure, 1),
    "p_up": round(p_up, 2),
    "expected_return_pct": round(expected_return, 2),
    "expected_vol_pct": round(expected_vol, 2),
    "confidence": confidence,
    "reasoning": reasoning
}

with open('decision.json', 'w') as f:
    json.dump(decision, f, indent=2)

print(f"\n--- decision.json WRITTEN ---")
print(json.dumps(decision, indent=2))
print("\nDone.")
