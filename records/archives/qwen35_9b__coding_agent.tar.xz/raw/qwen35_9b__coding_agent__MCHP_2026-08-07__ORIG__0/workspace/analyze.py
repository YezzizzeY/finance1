import pandas as pd
import numpy as np
from datetime import datetime

# Load data
prices = pd.read_csv('prices.csv', parse_dates=['date'])
news = pd.read_csv('news.csv', parse_dates=['time'])

account = {
    'cash': 94798.36,
    'shares': 67,
    'total_assets': 100472.59,
    'close': 84.69,
    'shares_per_exposure_point': 11.9
}

# Filter prices to get from 2026-07-27 to 2026-08-07
target_date = datetime(2026, 8, 7)
prices = prices[prices['date'] >= '2026-07-27']
prices = prices.sort_values('date').reset_index(drop=True)

print("="*60)
print("TECHNICAL ANALYSIS - TODAY (2026-08-07)")
print("="*60)

close = prices['close']
last_row = prices.iloc[-1]
today_close = last_row['close']

print(f"\nToday's Close: ${today_close:.2f}")

# EMA calculations
ema8 = close.ewm(span=8).mean()
ema21 = close.ewm(span=21).mean()
ema55 = close.ewm(span=55).mean()

ema8_val = ema8.iloc[-1]
ema21_val = ema21.iloc[-1]
ema55_val = ema55.iloc[-1]

print(f"\nEMA(8): ${ema8_val:.2f}")
print(f"EMA(21): ${ema21_val:.2f}")  
print(f"EMA(55): ${ema55_val:.2f}")

# RSI
delta = close.diff()
gain = (delta.where(delta > 0, 0)).rolling(window=14).mean()
loss = (-delta.where(delta < 0, 0)).rolling(window=14).mean()
rs = gain / loss
rsi = 100 - (100 / (1 + rs))
rsi_val = rsi.iloc[-1]
print(f"\nRSI (14): {rsi_val:.1f}")

# Bollinger Bands
sma = close.rolling(window=20).mean()
std = close.rolling(window=20).std()
upper = sma + 2 * std
lower = sma - 2 * std

boll_upper = upper.iloc[-1]
boll_lower = lower.iloc[-1]
boll_pos = (today_close - boll_lower) / (boll_upper - boll_lower)
print(f"\nSMA (20): ${sma.iloc[-1]:.2f}")
print(f"Bollinger Upper: ${boll_upper:.2f}")
print(f"Bollinger Lower: ${boll_lower:.2f}")
print(f"Bollinger Position: {boll_pos:.2f}")

# Z-score (mean reversion)
z_score = (today_close - sma.iloc[-1]) / std.iloc[-1]
print(f"\nZ-Score (50d): {z_score:.2f}")

# MACD
exp1 = close.ewm(span=12).mean()
exp2 = close.ewm(span=26).mean()
macd = exp1 - exp2
macd_signal = macd.ewm(span=9).mean()
macd_hist = macd - macd_signal
print(f"\nMACD: {macd.iloc[-1]:.2f}")
print(f"MACD Signal: {macd_signal.iloc[-1]:.2f}")
print(f"MACD Histogram: {macd_hist.iloc[-1]:.2f}")

# Calculate returns
recent_prices = prices['close'].iloc[-10:]
return_10d = ((today_close / recent_prices.iloc[0]) - 1) * 100

print(f"\n10-day return: {return_10d:.2f}%")

# ATR
atr_14 = close.ewm(span=14).mean()
atr_val = atr_14.iloc[-1]
atr_pct = (atr_val / today_close) * 100
print(f"\nATR (14): ${atr_val:.2f} ({atr_pct:.1f}%)")

# Support/Resistance
resistance = [92.02, 90.85, 85.66]
support = [72.58, 78.0, 81.6]
nearest_resistance = min(resistance, key=lambda x: abs(x - today_close))
nearest_support = max(support, key=lambda x: abs(x - today_close))

dist_res = nearest_resistance - today_close
dist_sup = today_close - nearest_support
print(f"\nNearest Resistance: ${nearest_resistance} (dist: {dist_res:.2f}, {dist_res/today_close*100:.1f}%)")
print(f"Nearest Support: ${nearest_support} (dist: {dist_sup:.2f}, {dist_sup/today_close*100:.1f}%)")

# Historical returns analysis
print("\n" + "="*60)
print("HISTORICAL RETURNS (for forecast estimation)")
print("="*60)

# Get more historical data for better estimate
full_prices = pd.read_csv('prices.csv', parse_dates=['date'])
full_prices = full_prices.sort_values('date').reset_index(drop=True)

# Calculate 5-day rolling returns
n = len(full_prices)
daily_returns = full_prices['close'].pct_change() * 100

returns_5d = []
for i in range(60, n):
    roi = (full_prices['close'].iloc[i] / full_prices['close'].iloc[i-5]) - 1
    returns_5d.append(roi)

returns_5d = np.array(returns_5d)
print(f"\n5-day returns sample (recent 30):")
sample_30 = returns_5d[-30:]
print(f"Range: {sample_30.min():.2f}% to {sample_30.max():.2f}%")
print(f"Mean: {sample_30.mean():.2f}%")
print(f"Std: {sample_30.std():.2f}%")

# P-value estimate
# Using normal distribution: probability that return > 0
# standard normal z = 0 gives p = 0.5
p_up = 0.52  # Slightly optimistic due to earnings

# Expected return and volatility (5-day)
mean_5d = sample_30.mean()
std_5d = sample_30.std()

expected_return_5d = mean_5d * 2  # Doubled mean for longer horizon
vol_5d = std_5d * np.sqrt(5)  # Scale volatility

print(f"\n5-day forecast based on history:")
print(f"Mean return: {mean_5d:.2f}%")
print(f"Std dev: {std_5d:.2f}%")
print(f"Expected 5-day return: {expected_return_5d:.2f}%")
print(f"Expected 5-day vol: {vol_5d:.2f}%")

# News analysis
print("\n" + "="*60)
print("NEWS ANALYSIS")
print("="*60)

positive_keywords = ['beat', 'grow', 'growth', 'guidance', 'bull', 'upside', 'strong', 'record']
negative_keywords = ['lower', 'bear', 'cut', 'risk', 'weak', 'decline', 'skeptic']

news_recent = news[['time', 'headline', 'summary']].tail(20)
news_head = news_recent['headline'].str.lower()
news_sum = news_recent['summary'].str.lower()
news_text = news_head + ' ' + news_sum

pos_count = sum(1 for t in news_text if any(k in t for k in positive_keywords))
neg_count = sum(1 for t in news_text if any(k in t for k in negative_keywords))

print(f"\nPositive mentions: {pos_count}")
print(f"Negative mentions: {neg_count}")
print(f"News sentiment: {'Positive' if pos_count > neg_count else 'Negative' if neg_count > pos_count else 'Balanced'}")

# Current position
print("\n" + "="*60)
print("POSITION ANALYSIS")
print("="*60)

current_exposure = (account['shares'] * today_close) / account['total_assets'] * 100
print(f"Current Position: {account['shares']} shares")
print(f"Position Value: ${account['shares'] * today_close:.2f}")
print(f"Current Exposure: {current_exposure:.1f}%")
print(f"Cash Available: ${account['cash']:.2f}")
print(f"One exposure point in shares: {account['shares_per_exposure_point']}")

# Yesterday's move
yesterday_close = prices.iloc[-2]['close']
move_pct = ((today_close - yesterday_close) / yesterday_close) * 100
print(f"\nYesterday's close: ${yesterday_close:.2f}")
print(f"Today's daily move: {move_pct:+.1f}%")

# Decision factors
print("\n" + "="*60)
print("DECISION FACTORS")
print("="*60)
print(f"\n1. Price Action: Today = ${today_close:.2f} vs Yesterday = ${yesterday_close:.2f} (+{move_pct:.1f}%)")
print(f"   - Big daily move of 13%+ suggests volatility regime")

print(f"\n2. Technicals:")
print(f"   - EMAs: Price { 'above' if today_close > ema21_val else 'below' } EMA21 (${ema21_val:.2f})")
print(f"   - RSI: {rsi_val:.1f} (neutral zone: 40-60)")
print(f"   - Bollinger: Position {boll_pos:.2f} between bands")
print(f"   - Z-Score: {z_score:.2f} (>{ 'mean by' if z_score > 0 else 'below mean by' } abs({abs(z_score):.2f}) std)")
print(f"   - MACD histogram: {macd_hist.iloc[-1]:+.2f} (neutral/+trend)")

print(f"\n3. News/Events:")
print(f"   - Earnings beat Q1")
print(f"   - Data center revenue +98%")
print(f"   - Analysts lowered PTs ($120, $95, $90) despite buy ratings")

print(f"\n4. Risk Factors:")
print(f"   - Volatility regime: 'high' (89.6% annualized)")
print(f"   - Vol z-score: 1.68 (above average)")
print(f"   - Note: 'After large moves the next few days are usually larger'")

print("\n" + "="*60)
print("DECISION LOGIC")
print("="*60)
print(f"\nKey consideration:")
print(f"  - Stock had 13% single-day move in high volatility regime")
print(f"  - Historically, large moves are followed by continued volatility")
print(f"  - Elevated RSI near 55 (slightly overheated)")
print(f"  - Z-score > 1.6 suggests some mean reversion pressure")
print(f"  - But earnings beat provides fundamental support")
print(f"  - Current 5.6% exposure is already built")

# Make decision
# Trade-off: Hold to allow volatility to work itself out, rather than chase upside
# or sell and take profits from recent surge

# Decision: HOLD - Don't add to position after such a big move
# Let volatility settle, avoid selling too early since underlying strength is real

action = "Hold"
shares = account['shares']
target_exposure = current_exposure

print(f"\n" + "="*60)
print(f"FINAL DECISION")
print("="*60)
print(f"\nAction: {action}")
print(f"Shares: {shares}")
print(f"Target Exposure: {target_exposure:.1f}%")

# Forecast
# Conservative estimate given recent volatility
p_up = 0.53  # Slight edge to upside from fundamentals
expected_return = 0.6  # ~0.6% over 5 days (modest)
expected_vol = 4.5  # ~4.5% one-sd over 5 days (conservative)
confidence = 0.55  # Moderate confidence due to volatility regime

print(f"\nForecast (Next 5 Trading Days):")
print(f"  p_up: {p_up:.2f}")
print(f"  expected_return_pct: {expected_return:.2f}%")
print(f"  expected_vol_pct: {expected_vol:.2f}%")
print(f"\n  Reasoning: Earnings beat provides support; volatility high; mean reversion pressure from +13% daily move")
print(f"  Confidence: {confidence:.0%}")

print("\n" + "="*60)
print("GENERATING decision.json")
print("="*60)

decision = {
    "action": action,
    "shares": int(shares),
    "target_exposure_pct": round(target_exposure, 1),
    "p_up": round(p_up, 2),
    "expected_return_pct": round(expected_return, 2),
    "expected_vol_pct": round(expected_vol, 2),
    "confidence": round(confidence, 2),
    "reasoning": "Held after 13% daily move in high volatility regime; earnings beat provides fundamental support but analyst PT cuts and elevated RSI suggest patience; current 5.6% exposure appropriate"
}

with open('decision.json', 'w') as f:
    import json
    json.dump(decision, f, indent=2)

print(f"\ndecision.json written:")
import json
print(json.dumps(decision, indent=2))
