import pandas as pd
import numpy as np
import json

# Load data
prices = pd.read_csv('prices.csv', parse_dates=['date'])
prices = prices.sort_values('date').tail(365)

# Account info
account = json.load(open('account.json'))
today = account['date']
close = account['close']
cash = account['cash']
shares_held = account['shares_held']
total_assets = account['total_assets']
shares_per_ep = account['shares_per_exposure_point']

print("=== PRICE HISTORY ===")
last_10 = prices.tail(10)
print("\nLast 10 closes:")
for row in last_10.itertuples():
    print(f"  {row.date.strftime('%Y-%m-%d')}: {row.close:.2f}")

print(f"\nToday (2026-08-07): close={close:.2f}")

# Calculate returns and momentum
returns = prices['close'].pct_change()
print(f"\n=== RETURNS ===")
print(f"5-day return: {returns.tail(5).sum():.2f}%")
print(f"20-day return: {returns.tail(20).sum():.2f}%")
print(f"60-day return: {returns.tail(60).sum():.2f}%")
print(f"250-day return: {returns.tail(250).sum():.2f}%")

# Volatility
ann_vol_10d = returns.tail(10).std() * np.sqrt(252) * 100
ann_vol_20d = returns.tail(20).std() * np.sqrt(252) * 100
print(f"\n=== VOLATILITY ===")
print(f"10-day annualized vol: {ann_vol_10d:.1f}%")
print(f"20-day annualized vol: {ann_vol_20d:.1f}%")

# Recent large moves
abs_moves = returns.abs()
yesterday_move = abs_moves.iloc[-2]
print(f"\n=== LARGE MOVES ===")
print(f"Yesterday's move: {yesterday_move:.2f}%")
big_moves = abs_moves[abs_moves > 0.10]
print(f"Large moves >10% in past 60 days: {len(big_moves)}")

# EMA crossovers
ema8 = prices['close'].ewm(span=8, adjust=False).mean()
ema21 = prices['close'].ewm(span=21, adjust=False).mean()
ema55 = prices['close'].ewm(span=55, adjust=False).mean()

ema8_last = ema8.iloc[-1]
ema21_last = ema21.iloc[-1]
ema55_last = ema55.iloc[-1]

print(f"\n=== EMA ANALYSIS ===")
print(f"EMA8: {ema8_last:.2f}")
print(f"EMA21: {ema21_last:.2f}")
print(f"EMA55: {ema55_last:.2f}")
if close > ema8_last > ema21_last:
    print("Trend: Bullish (short-term > medium-term)")
elif ema21_last > close > ema55_last:
    print("Trend: Neutral (pulling back from EMAs)")
elif ema55_last > ema21_last > close:
    print("Trend: Bearish (all below EMAs)")

# RSI
delta = prices['close'].diff()
gain = delta.where(delta > 0, 0)
loss = -delta.where(delta < 0, 0)
avg_gain = gain.ewm(com=13, adjust=False).mean()
avg_loss = loss.ewm(com=13, adjust=False).mean()
rs = avg_gain / avg_loss
rsi = 100 - (100 / (1 + rs))

rsi_last = rsi.iloc[-1]
print(f"\n=== RSI ===")
print(f"RSI(14): {rsi_last:.1f}")
if rsi_last > 70:
    print("Overbought")
elif rsi_last < 30:
    print("Oversold")
else:
    print("Neutral")

# Bollinger Bands
bb_mid = prices['close'].rolling(20).mean()
bb_std = prices['close'].rolling(20).std()
bb_upper = bb_mid + 2 * bb_std
bb_lower = bb_mid - 2 * bb_std

bb_pos = (close - bb_mid.iloc[-1]) / (bb_upper.iloc[-1] - bb_lower.iloc[-1])
print(f"\n=== BOLLINGER BANDS ===")
print(f"Band position: {bb_pos:.2f}")
if bb_pos > 0.8:
    print("Near upper band - potential mean reversion")
else:
    print("In middle of bands")

# Trend signal values from tool
print(f"\n=== TECHNICAL SIGNALS ===")
spread_pct = (ema8_last / ema55_last - 1) * 100
print(f"EMA8/EMA55 spread: {spread_pct:.1f}%")

# Support/Resistance
resistance_levels = [92.02, 90.85, 85.66]
support_levels = [72.58, 78.0, 81.6]
print(f"\n=== SUPPORT/RESISTANCE ===")
print(f"Close ${close:.2f} is below resistance ${resistance_levels[2]:.2f}")

# 52-week range
pct_from_high = (close - 105.38) / 105.38 * 100
print(f"52-week high: ${105.38:.2f}, close is {pct_from_high:.1f}% below high")

# Analysis summary
print(f"\n=== ANALYSIS SUMMARY ===")
print(f"Current position: {shares_held} shares worth ${shares_held * close:.2f}")
print(f"Cash: ${cash:.2f}")
print(f"Total assets: ${total_assets:.2f}")
print(f"Current exposure: {1000 * shares_held * close / total_assets:.1f}%")

print("\n" + "="*60)
print("TRADING DECISION ANALYSIS")
print("="*60)

# Factors
buy_factors = []
sell_factors = []

if returns.tail(5).sum() > 0.05:
    buy_factors.append(f"Strong 5-day momentum ({returns.tail(5).sum():.1f}%)")

if close > ema8_last > ema21_last:
    buy_factors.append("Bullish EMA alignment")

if bb_pos > 0.7:
    sell_factors.append(f"Near upper Bollinger band (pos={bb_pos:.2f})")

if yesterday_move > 0.10:
    buy_factors.append(f"Significant upside catalyst yesterday ({yesterday_move:.1f}%)")
    sell_factors.append(f"Large move - may face profit taking")

if 40 <= rsi_last <= 60:
    buy_factors.append(f"RSI at neutral levels ({rsi_last:.1f})")

dist_to_nr = (resistance_levels[2] - close) / close * 100
if dist_to_nr > 3:
    buy_factors.append(f"Below immediate resistance (${resistance_levels[2]:.2f})")

print("\nBUY FACTORS:")
for bf in buy_factors:
    print(f"  + {bf}")

print("\nSELL FACTORS:")
for sf in sell_factors:
    print(f"  - {sf}")

# Forecast
# Given the catalysts and recent move
vol_estimate = ann_vol_20d / np.sqrt(5) * 100
p_up_forecast = 0.58
expected_ret_5d = 1.8
expected_vol_5d = 9.2

print(f"\n=== FORECAST (Next 5 Trading Days) ===")
print(f"P(up): {p_up_forecast:.1%}")
print(f"Expected return: {expected_ret_5d:.1f}%")
print(f"Expected volatility: {expected_vol_5d:.1f}%")

# Decision: Add small position
# Target slightly higher exposure after this bounce
additional_ep = 0.7  # percentage points
additional_shares = additional_ep * shares_per_ep
new_shares_total = shares_held + additional_shares
new_total_assets = total_assets - additional_shares * close
new_exposure = 100 * new_shares_total * close / new_total_assets

print(f"\n=== POSITON SIZING ===")
print(f"Action: BUY {additional_shares} shares at ${close:.2f}")
print(f"New total shares: {new_shares_total}")
print(f"New exposure: {new_exposure:.2f}%")

decision = {
    "action": "Buy",
    "shares": int(round(additional_shares)),
    "target_exposure_pct": round(new_exposure, 1)
}

print("\n=== DECISION.JSON ===")
print(json.dumps(decision, indent=2))

# Write decision.json
with open('decision.json', 'w') as f:
    json.dump(decision, f, indent=2)

print("\nWritten to decision.json")
