import pandas as pd, numpy as np

df = pd.read_csv('prices.csv', parse_dates=['date']).sort_values('date').reset_index(drop=True)
df['ret'] = df['close'].pct_change()
print("rows:", len(df), "first:", df.date.iloc[0].date(), "last:", df.date.iloc[-1].date())

df['high52'] = df['high'].rolling(252, min_periods=60).max()
df['z50'] = (df['close'] - df['close'].rolling(50).mean()) / df['close'].rolling(50).std()
tr = pd.concat([df.high-df.low, (df.high-df.close.shift()).abs(), (df.low-df.close.shift()).abs()], axis=1).max(axis=1)
df['atr14'] = tr.rolling(14).mean() / df['close']
df['ann20'] = df['ret'].rolling(20).std()*np.sqrt(252)
df['fwd5'] = df['close'].shift(-5)/df['close'] - 1
df['fwd1'] = df['close'].shift(-1)/df['close'] - 1

last = df.iloc[-1]
print(f"\n=== today === close {last.close:.2f} ret {last.ret*100:.2f}% z50 {last.z50:.2f} ann20 {last.ann20*100:.1f}% atr% {last.atr14*100:.2f}% dist52wH {(last.close/last.high52-1)*100:.2f}%")

f = df['fwd5'].dropna().tail(250)
print(f"\n5d fwd (last 250 obs): mean {f.mean()*100:.2f}% median {f.median()*100:.2f}% std {f.std()*100:.2f}% P(>0) {(f>0).mean():.3f}")
print(f"quartiles pct: {np.percentile(f*100,[0,25,50,75,100]).round(2)}")

big = df[(df['ret']>=0.12) & df['fwd5'].notna()]
print(f"\n=== after up-days >=12%: n={len(big)} ===")
if len(big):
    print(big[['date','ret','z50','fwd5','fwd1']].to_string())
    print(f"fwd5 mean {big.fwd5.mean()*100:.2f}% P(>0) {(big.fwd5>0).mean():.3f}")
    print(f"fwd1 mean {big.fwd1.mean()*100:.2f}% P(>0) {(big.fwd1>0).mean():.3f}")

big2 = df[(df['ret']>=0.10) & df['fwd5'].notna()]
print(f"\n=== after up-days >=10%: n={len(big2)} ===")
print(big2[['date','ret','z50','fwd5']].to_string())
if len(big2):
    print(f"fwd5 mean {big2.fwd5.mean()*100:.2f}% P(>0) {(big2.fwd5>0).mean():.3f} std {big2.fwd5.std()*100:.2f}%")

z = df[(df['z50']>=1.5) & df['fwd5'].notna()]
print(f"\n=== z50>=1.5: n={len(z)} fwd5 mean {z.fwd5.mean()*100:.2f}% P(>0) {(z.fwd5>0).mean():.3f} std {z.fwd5.std()*100:.2f}%")
h = df[(df['close']/df['high52']>=0.97) & df['fwd5'].notna()]
print(f"=== within 3% of 52w high: n={len(h)} fwd5 mean {h.fwd5.mean()*100:.2f}% P(>0) {(h.fwd5>0).mean():.3f} std {h.fwd5.std()*100:.2f}%")
c = df[(df['ret']>=0.10) & (df['close']/df['high52']>=0.95) & df['fwd5'].notna()]
print(f"=== >=10% up & near 52w high: n={len(c)}")
if len(c): print(c[['date','ret','fwd5','fwd1']].to_string())

base5 = df['fwd5'].dropna().tail(500).std()
after_big = df[df['ret'].abs()>=0.10]['fwd5'].dropna().std()
print(f"\nbaseline 5d std {base5*100:.2f}% vs after |move|>=10%: {after_big*100:.2f}%")
pm = df[(df['ret']>0) & df['fwd5'].notna()].tail(400)
print(f"after any up day (last 400): fwd5 mean {pm.fwd5.mean()*100:.2f}% P(>0) {(pm.fwd5>0).mean():.3f}")
