import csv, math, statistics as st

rows = []
with open('prices.csv') as f:
    for r in csv.DictReader(f):
        rows.append((r['date'], float(r['open']), float(r['high']), float(r['low']), float(r['close']), int(r['volume'])))

dates = [r[0] for r in rows]
close = [r[4] for r in rows]
n = len(close)
print("rows:", n, "first:", dates[0], "last:", dates[-1], "last close:", close[-1])

# daily log-ish simple returns
ret = [close[i]/close[i-1]-1 for i in range(1, n)]

def stats(xs):
    if len(xs) < 2: return None
    m = st.mean(xs)
    sd = st.stdev(xs)
    p_up = sum(1 for x in xs if x > 0)/len(xs)
    med = st.median(xs)
    return dict(n=len(xs), mean=100*m, sd=100*sd, med=100*med, p_up=p_up,
                p5=100*sorted(xs)[max(0,int(0.05*len(xs))-1)], p95=100*sorted(xs)[min(len(xs)-1,int(0.95*len(xs)))])

def fmt(s):
    if s is None: return "  (n<2)"
    return f"n={s['n']:3d} mean={s['mean']:+6.2f}% sd={s['sd']:5.2f}% med={s['med']:+6.2f}% p_up={s['p_up']:.2f} p05={s['p5']:+6.2f}% p95={s['p95']:+6.2f}%"

# 5-day forward returns: from close[i] to close[i+5]
fwd5 = {}
for i in range(n-5):
    fwd5[i] = close[i+5]/close[i]-1

allf = [fwd5[i] for i in sorted(fwd5)]
print("\nBASELINE all 5d fwd:", fmt(stats(allf)))

# recent-window baselines
for label, lo in [("last 250d", n-251), ("last 126d", n-127), ("last 63d", n-64)]:
    xs = [fwd5[i] for i in sorted(fwd5) if i >= lo and i < n-5]
    print(f"BASELINE {label}:", fmt(stats(xs)))

# conditional on same-day return
def cond(lo_r=None, hi_r=None, lo=None, hi=None, label=""):
    xs = []
    idxs = []
    for i in sorted(fwd5):
        if i < 1: continue
        r = ret[i-1]  # return of day i (indexed by close ratio); ret[k] is day k+1 vs k
        # careful: ret[i] = close[i]/close[i-1]-1, i.e. return on day i
        if lo_r is not None and not (r >= lo_r): continue
        if hi_r is not None and not (r < hi_r): continue
        if lo is not None and i < lo: continue
        xs.append(fwd5[i]); idxs.append(i)
    print(f"COND {label}: ret day {('>= %.1f%%'%(lo_r*100)) if lo_r is not None else ''} {('< %.1f%%'%(hi_r*100)) if hi_r is not None else ''}", fmt(stats(xs)), "days:", [dates[i] for i in idxs])
    return xs

print()
cond(lo_r=0.12, label="big up >=+12%")
cond(lo_r=0.10, label="up >=+10%")
cond(lo_r=0.08, label="up >=+8%")
cond(lo_r=0.05, hi_r=0.10, label="up +5..10%")
cond(lo_r=0.02, hi_r=0.05, label="up +2..5%")
cond(hi_r=-0.02, lo_r=-0.08, label="down -2..-8%")
cond(hi_r=-0.08, label="down <=-8%")

# high-vol regime conditioning: today's vol regime is 'high' (10d vol zscore 1.68)
# rolling 10d realized vol (sd of daily returns over prior 10 days), z-score vs prior 63d
def rolling_vol(i, w):
    if i < w: return None
    xs = ret[i-w:i]
    return st.pstdev(xs)

print("\nREGIME: days where prior-10d vol was in top decile of history, and day return >= +8%:")
vols = []
for i in range(10, n):
    vols.append((rolling_vol(i,10), i))
vols_sorted = sorted(v for v,_ in vols)
thr = vols_sorted[int(0.90*len(vols_sorted))]
xs = []
idxs=[]
for i in sorted(fwd5):
    if i < 10: continue
    v = rolling_vol(i,10)
    if v is None or v < thr: continue
    if ret[i] >= 0.08:
        xs.append(fwd5[i]); idxs.append(i)
print(f"  vol10 thr={100*thr:.2f}%", fmt(stats(xs)), [dates[i] for i in idxs])

# top decile vol regime, any day, 5d fwd (for vol calibration)
xs = [fwd5[i] for i in sorted(fwd5) if i>=10 and rolling_vol(i,10) is not None and rolling_vol(i,10)>=thr]
print("  high-vol regime ALL days 5d fwd:", fmt(stats(xs)))

# 5d vol estimate from realized: sd of 5d fwd in different windows
for label, lo in [("full", 1), ("last 250d", n-251), ("last 126d", n-127), ("last 63d", n-64)]:
    xs = [fwd5[i] for i in sorted(fwd5) if i >= lo]
    s = stats(xs)
    print(f"5d fwd sd {label}: {s['sd']:.2f}%")

# what do big-up days look like path-wise? enumerate >=+10% days with fwd path (next 5 closes)
print("\nBIG UP DAYS (>=+10%) paths:")
for i in range(1, n-5):
    if ret[i] >= 0.10:
        path = [f"{100*(close[j]/close[i]-1):+.1f}%" for j in range(i+1, i+6)]
        print(f"  {dates[i]} ret={100*ret[i]:+.1f}% close={close[i]:.2f} next5: {path}")

# also last 60 days day by day for context
print("\nLAST 12 DAYS:")
for i in range(n-12, n):
    print(f"  {dates[i]} close={close[i]:8.2f} ret={100*ret[i]:+6.2f}% vol={int(rows[i][5]):,}")
