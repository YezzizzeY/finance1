import csv, statistics as st
rows = []
with open('prices.csv') as f:
    for r in csv.DictReader(f):
        rows.append((r['date'], float(r['open']), float(r['high']), float(r['low']), float(r['close']), int(r['volume'])))
dates=[r[0] for r in rows]; close=[r[4] for r in rows]; vol=[r[5] for r in rows]
n=len(close)
ret=[None]+[close[i]/close[i-1]-1 for i in range(1,n)]
fwd={i: close[i+5]/close[i]-1 for i in range(n-5)}

def stats(xs):
    if len(xs)<2: return f"n={len(xs)}"
    s=sorted(xs)
    return f"n={len(xs)} mean={100*st.mean(xs):+6.2f}% sd={100*st.stdev(xs):5.2f}% med={100*st.median(xs):+6.2f}% p_up={sum(1 for x in xs if x>0)/len(xs):.2f}"

# CORRECTED: fresh spike = same-day >=+8% AND prior 5d (i-6 -> i-1) <= +2%
print("Fresh-spike analogs (same-day>=+8%, prior 5d thru yesterday <=+2%):")
fresh=[]
for i in range(6, n-5):
    if ret[i]>=0.08 and close[i-1]/close[i-6]-1 <= 0.02:
        f5=fwd[i]
        fresh.append(f5)
        print(f"  {dates[i]} same={100*ret[i]:+.2f}% prior5={100*(close[i-1]/close[i-6]-1):+.2f}% vol_x={vol[i]/(sum(vol[i-20:i])/20):.2f} fwd5={100*f5:+.2f}% path="+" ".join(f"{100*(close[j]/close[i]-1):+.1f}" for j in range(i+1,i+6)))
print("  stats:", stats(fresh))

# top 15 single-day gains in 3y, with fwd5
ranked = sorted([(ret[i], i) for i in range(1, n-5)], reverse=True)[:15]
print("\nTop 15 daily gains:")
for r, i in ranked:
    print(f"  {dates[i]} {100*r:+6.2f}%  fwd5={100*fwd[i]:+6.2f}%")

# today's context numbers
i = n-1
print(f"\nToday {dates[i]}: ret={100*ret[i]:+.2f}%, prior5 thru yesterday={100*(close[i-1]/close[i-6]-1):+.2f}%, prior20={100*(close[i-1]/close[i-21]-1):+.2f}%")
print(f"close vs day high: {100*(rows[i][4]-rows[i][1])/rows[i][1]:+.2f}%; vol_x vs 20d: {vol[i]/(sum(vol[i-20:i])/20):.2f}")

# account math
shares=67; px=84.69; cash=94798.36
tot=cash+shares*px
print(f"\nAccount: pos={shares*px:.2f} total={tot:.2f} pct={100*shares*px/tot:.3f}%")
cost=(64*77.79+3*74.36)/67
print(f"avg cost={cost:.2f} unrealized={100*(px/cost-1):+.1f}%")
for s in (65,67,69,79):
    t2=cash+shares*px; t2=cash+(s)*px  # if trading at close, cash adjusts
    print(f"  if hold {s} shares: pct={100*s*px/(cash+(s)*px):.2f}%")
