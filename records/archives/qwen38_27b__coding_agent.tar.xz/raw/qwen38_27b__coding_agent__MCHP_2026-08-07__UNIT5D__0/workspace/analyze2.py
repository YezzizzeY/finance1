import csv, statistics as st

rows = []
with open('prices.csv') as f:
    for r in csv.DictReader(f):
        rows.append((r['date'], float(r['open']), float(r['high']), float(r['low']), float(r['close']), int(r['volume'])))
dates = [r[0] for r in rows]; close = [r[4] for r in rows]; vol = [r[5] for r in rows]
n = len(close)
# ret[i] = return ON day i (from i-1 to i), i>=1
ret = [None] + [close[i]/close[i-1]-1 for i in range(1, n)]
fwd = {}
for i in range(n-5):
    fwd[i] = close[i+5]/close[i]-1

def stats(xs):
    if len(xs) < 2: return f"n={len(xs)}"
    s = sorted(xs)
    return f"n={len(xs)} mean={100*st.mean(xs):+6.2f}% sd={100*st.stdev(xs):5.2f}% med={100*st.median(xs):+6.2f}% p_up={sum(1 for x in xs if x>0)/len(xs):.2f} min={100*s[0]:+6.2f}% max={100*s[-1]:+6.2f}%"

print("=== Exact 5d-fwd values for big up days (>=+8%), same-day conditioned ===")
big = [(i, ret[i]) for i in range(1, n-5) if ret[i] >= 0.08]
for i, r in big:
    f5 = fwd[i]
    f1 = close[i+1]/close[i]-1
    volr = vol[i]/(sum(vol[max(0,i-20):i])/min(20,i))
    path = " ".join(f"{100*(close[j]/close[i]-1):+5.1f}" for j in range(i+1, i+6))
    print(f"{dates[i]} same-day={100*r:+6.2f}% vol_x={volr:4.2f} fwd1={100*f1:+6.2f}% fwd5={100*f5:+6.2f}% | path: {path}")

xs8 = [fwd[i] for i,_ in big]
print(">=+8% fwd5 all:", stats(xs8))
print(">=+8% fwd1 all:", stats([close[i+1]/close[i]-1 for i,_ in big]))

print()
print("=== Context conditionals (same-day) ===")
def filt(pred, label):
    xs = [fwd[i] for i in range(1, n-5) if ret[i] is not None and pred(i)]
    print(f"{label}: {stats(xs)}")

filt(lambda i: ret[i] >= 0.08 and (close[i-5]/close[i-10] if i>=10 else 1) <= 1.02, "up>=8% AND prior 5d <=+2% (fresh breakout, like today)")
filt(lambda i: ret[i] >= 0.08 and i>=20 and vol[i]/(sum(vol[i-20:i])/20) >= 1.8, "up>=8% AND vol>=1.8x 20d-avg (event day)")
filt(lambda i: ret[i] >= 0.08 and (close[i-1]-rows[i][3])/rows[i][3] < 0.05, "up>=8% AND close in top ~5% of day range (strong close)")
filt(lambda i: ret[i] >= 0.05 and ret[i] < 0.10, "up +5..10%")
filt(lambda i: ret[i] >= 0.08 and i>=20 and close[i] < close[i-20], "up>=8% but still below 20d-ago close (oversold base)")

print()
print("=== Vol calibration for 5-day horizon ===")
def roll_sd(i, w):
    return st.pstdev([close[j]/close[j-1]-1 for j in range(i-w+1, i+1)])
# 5d-ahead vol from realized 5d returns, trailing windows
for label, lo in [("full hist", 1), ("last 250d", n-251), ("last 63d", n-63)]:
    xs = [fwd[i] for i in sorted(fwd) if i >= lo]
    print(f"sd of 5d fwd returns, {label}: {100*st.stdev(xs):.2f}%")
# daily vol last 10/20/60 days, scaled to 5d
for w in (10, 20, 60):
    d = st.pstdev([close[j]/close[j-1]-1 for j in range(n-w, n)])
    print(f"5d-equiv vol from {w}d daily sd: {100*d*(5**0.5):.2f}%")
# ATR14-based
trs = [max(rows[i][1]-rows[i][2], abs(rows[i][1]-rows[i-1][4]), abs(rows[i][2]-rows[i-1][4])) for i in range(n-14, n)]
atr14 = sum(trs)/14
print(f"ATR14 = {atr14:.2f} = {100*atr14/close[n-1]:.2f}% of price; 5d-equiv (x sqrt5): {100*atr14*(5**0.5)/close[n-1]:.2f}%")

print()
print("=== Post-earnings analogs detail (Dec 2025 / Jan 2026 & Apr-May 2025) ===")
for i in range(1, n-1):
    if dates[i] in ("2025-12-03","2025-12-04","2026-01-05","2026-01-06","2026-04-23"):
        print(f"{dates[i]} ret={100*ret[i]:+6.2f}% close={close[i]:.2f} fwd1={100*(close[i+1]/close[i]-1):+6.2f}% fwd5={100*fwd.get(i, float('nan')):+6.2f}%")
